package com.example.a001759.pregtrack.activities;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.example.a001759.pregtrack.R;

public class CreateAppointment extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_appointment);
    }
}
